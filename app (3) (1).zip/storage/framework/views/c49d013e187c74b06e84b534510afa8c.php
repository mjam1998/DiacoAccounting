 <?php $__env->startSection('content'); ?>

     <!-- begin::page loader-->
     <div class="page-loader">
         <div class="spinner-border"></div>
     </div>
     <!-- end::page loader -->

     <div class="form-wrapper " style="border:1px solid #0d153c;">

         <!-- logo -->
         <div class="logo"  >
             <img src="<?php echo e(asset('AdminPanel/assets/media/image/accounting.png')); ?>" class="img-fluid" alt="image">
         </div>
         <!-- ./ logo -->
         <h2>نرم افزار حسابداری دیاکو</h2>
         <h5 style="color: #0d5ff5">ورود به حساب کاربری</h5>
         <?php if(session()->has('loginMessage')): ?>
             <div class="alert alert-danger">
                 <?php echo e(session()->get('loginMessage')); ?>

             </div>
         <?php endif; ?>
         <!-- form -->
         <form action="<?php echo e(route('login.post')); ?>" method="post">
             <?php echo csrf_field(); ?>
             <div class="form-group">
                 <input type="text" name="username" class="form-control text-left" placeholder="نام کاربری" dir="ltr" required autofocus>
             </div>
             <div class="form-group">
                 <input type="text" name="password" class="form-control text-left" placeholder=" رمز عبور" dir="ltr" required>
             </div>

             <button type="submit" class="btn btn-primary btn-block">ورود</button>
             <hr>

         </form>
         <!-- ./ form -->

 <?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/aminfir/app.aminf8.ir/resources/views/login.blade.php ENDPATH**/ ?>